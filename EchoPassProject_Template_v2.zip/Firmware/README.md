# Firmware Map
- Sensor drivers
- Fusion
- Haptics/Audio
- Power mgmt

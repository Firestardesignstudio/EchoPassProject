# Docking Spec
- Mechanical: diameter, length
- Electrical: pinout
- Protocols: I2C/UART/BLE

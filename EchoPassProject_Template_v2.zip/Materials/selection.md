# Materials
- Carbon tube / 6061 Alu
- O-ring (FKM)
- Grip (EPDM)

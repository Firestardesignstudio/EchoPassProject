---
name: Bug report
about: 不具合の報告
title: "[BUG] "
labels: bug
---
**現象**
**再現手順**
**期待動作**
**環境**（ハード/ファーム/OS）
**追加情報**

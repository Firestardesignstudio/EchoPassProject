# Wiring Overview
- Power path
- Sensor buses (I2C/UART)
- Protection (fuse/TVS)

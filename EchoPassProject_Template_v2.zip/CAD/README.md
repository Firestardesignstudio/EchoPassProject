# CAD Notes
- Units (mm)
- Tolerance
- Thread specs

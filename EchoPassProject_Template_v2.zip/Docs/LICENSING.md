# LICENSING (選び方ガイド)

**推奨組み合わせ**  
- Hardware: **CERN-OHL-P-2.0**（緩やか）/ **CERN-OHL-W-2.0**（弱コピレフト）  
- Software: **MIT** または **Apache-2.0**（特許条項が必要なら Apache）  
- Docs/Images: **CC BY 4.0**

## 簡易比較
- MIT：最もシンプル。再利用自由、義務は著作権表記のみ。
- Apache-2.0：MITに加え**特許保護**が明記。企業採用に強い。
- CERN-OHL v2（P/W/S）：ハード向け。派生物の公開範囲を選べる。  
  - P（Permissive）：緩い。非公開派生も可。  
  - W（Weakly Reciprocal）：変更箇所の開示を求める。  
  - S（Strongly Reciprocal）：強いコピレフト。

## 使い方
1. このリポジトリから必要な LICENSE テキストを選択
2. ルートに `LICENSE` として配置
3. `README.md` に採用ライセンスを明記

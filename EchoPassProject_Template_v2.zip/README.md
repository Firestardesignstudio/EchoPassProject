# Echo Pass Project — オープンソース支援デバイス / Open Source Assistive Device

> 技術は支配のためではなく、共に生きるためにある。  
> Technology is not for control, but for coexistence.

このリポジトリは、視覚支援を中心とした**共生都市**の実装例（スマートステッキ等）のための、
ハードウェア＋ソフトウェアの**オープンソース**設計テンプレートです。

This repository is an **open-source** template for hardware + software designs
(e.g., smart cane) toward **coexistence-centric cities**.

---

## 🔧 構成 / Repository Layout

```
/Electronics      電気回路図・配線図・BOM
/Assembly         組立図・分解図・手順（写真/動画歓迎）
/CAD              3Dデータ（STEP/STL/IGES/DXF）と寸法公差
/Modules          モジュール連結仕様・ピン定義・拡張規格
/Materials        材料選定・表面処理・耐候性メモ
/Firmware         制御ロジック構成・擬似コード・API
/Docs             仕様書・安全ガイド・設計方針
/.github          Issue / PR テンプレート等
/Assets           画像・図版・ロゴ
```

## 🪪 ライセンス指針 / Licensing Guideline

- **ハードウェア**：CERN-OHL v2 （Permissive もしくは Weakly Reciprocal）  
- **ソフトウェア**：MIT もしくは Apache-2.0  
- **ドキュメント/画像**：CC BY 4.0

> 最終選択は `/Docs/LICENSING.md` を参照。

## 🤝 コントリビュート / Contributing

1. Issue を立て、改善提案や不具合を共有  
2. `fork` → `branch` → `pull request` の順で提案  
3. 回路・CAD の変更は**寸法・電気的互換性**の記述を必須とします

詳細は `CONTRIBUTING.md` を参照。

## 🌐 目的 / Purpose

- 地域差（雪国・旧市街・砂漠等）に**現地最適**で対応
- 技術を独占せず、**継続可能**なコミュニティで進化
- 誰もが安心して歩ける**共生都市**の実装

---

© 2025 Echo Pass Community — Open for public good.
